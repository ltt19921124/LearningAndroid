# 关注我的微信公众号学习更多技术

<img src="https://raw.githubusercontent.com/guolindev/booksource/master/qrcode.jpg" width="250" />

如果是对书中源码有疑问，也可以到公众号里给我留言。微信扫一扫上方二维码即可关注。
